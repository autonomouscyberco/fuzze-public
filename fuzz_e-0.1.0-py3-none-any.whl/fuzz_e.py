#!/usr/bin/env python3
"""
Reverse Proxy Agent with Registration, Token-Based Authentication,
and Burp Suite Integration (Supporting Both Direct and Burp Modes)

Usage:
    python agent.py --server <SERVER_IP_OR_HOST> --email user@example.com 
                    [--petname happy-daisy] [--token s3cr3t] [--burp_suite] [--test]

Workflow:
  1. On startup, the agent uses provided (or generated) petname and token.
  2. It connects to the server’s control port (5000) and sends a JSON registration message.
  3. If the --test flag is provided (with --burp_suite enabled), the agent sends a test HTTP GET
     request via Burp Suite (127.0.0.1:8080) to http://example.com/ and exits.
  4. Otherwise, the agent enters its normal control loop.
  5. For each command from the server, the agent opens a target connection (directly or via Burp)
     and a tunnel connection (to port 6000). For HTTPS (CONNECT) commands, it uses a CONNECT handshake
     when in Burp mode; for HTTP commands, it rewrites relative URLs to absolute (if using Burp).
  6. In every case the agent starts bidirectional relay threads so that responses are sent back to the server.
"""

import socket
import threading
import argparse
import json
import random, string
import logging
import os
import requests
import certifi
import ssl  # For certificate conversion using DER_cert_to_PEM_cert
import petname as petname_lib

CONTROL_SERVER_PORT = 5000
TUNNEL_SERVER_PORT = 6000

logger = logging.getLogger("agent")
logger.setLevel(logging.INFO)
if not logger.handlers:
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    formatter = logging.Formatter('[Agent] %(asctime)s - %(levelname)s - %(message)s',
                                  datefmt='%b %d, %Y at %H:%M:%S')
    ch.setFormatter(formatter)
    logger.addHandler(ch)
logger.propagate = False

def recv_line(sock):
    line = b""
    while not line.endswith(b"\n"):
        part = sock.recv(1)
        if not part:
            break
        line += part
    return line.decode("utf-8", errors="replace").strip()

def read_until(sock, delimiter: bytes) -> bytes:
    data = b""
    while delimiter not in data:
        chunk = sock.recv(4096)
        if not chunk:
            break
        data += chunk
    return data

def relay(src, dst):
    try:
        while True:
            data = src.recv(4096)
            if not data:
                break
            dst.sendall(data)
    except OSError as e:
        logger.error(f"Relay error: {e}")

def generate_random_string(n):
    return "".join(random.choice(string.ascii_lowercase + string.digits) for _ in range(n))

def connect_via_burp(target_host, target_port, timeout=5):
    try:
        sock = socket.create_connection(("127.0.0.1", 8080), timeout=timeout)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        connect_cmd = f"CONNECT {target_host}:{target_port} HTTP/1.1\r\nHost: {target_host}:{target_port}\r\n\r\n"
        sock.sendall(connect_cmd.encode("utf-8"))
        response = b""
        while b"\r\n\r\n" not in response:
            chunk = sock.recv(4096)
            if not chunk:
                break
            response += chunk
        if b"200 Connection established" not in response:
            raise Exception(f"Burp proxy failed to establish connection. Response: {response.decode('utf-8', errors='replace')}")
        logger.info(f"HTTP CONNECT to {target_host}:{target_port} succeeded via Burp Suite")
        return sock
    except Exception as e:
        logger.error(f"Error in connect_via_burp: {e}")
        raise

def download_burp_cert(cert_url, cert_path, proxies):
    try:
        logger.info(f"Downloading Burp certificate from {cert_url} through proxy...")
        response = requests.get(cert_url, proxies=proxies, verify=certifi.where())
        response.raise_for_status()
        with open(cert_path, 'wb') as f:
            f.write(response.content)
        logger.info(f"Certificate downloaded and saved to {cert_path}")
        return convert_cert_to_pem(cert_path)
    except Exception as e:
        logger.error(f"Failed to download Burp certificate: {e}")
        raise

def convert_cert_to_pem(cert_path):
    with open(cert_path, 'rb') as f:
        data = f.read()
    if data.startswith(b'-----BEGIN CERTIFICATE-----'):
        logger.info("Certificate already in PEM format.")
        return cert_path
    try:
        pem_cert = ssl.DER_cert_to_PEM_cert(data)
        pem_path = cert_path.replace('.crt', '.pem')
        with open(pem_path, 'w') as f:
            f.write(pem_cert)
        logger.info(f"Certificate converted and saved to {pem_path}")
        return pem_path
    except Exception as e:
        logger.error(f"Failed to convert certificate: {e}")
        raise

def register_agent(control_sock, email, petname, token):
    reg_msg = {"action": "register", "email": email, "petname": petname, "token": token}
    msg = json.dumps(reg_msg) + "\n"
    control_sock.sendall(msg.encode("utf-8"))
    logger.info(f"Registered with petname: {petname}, token: {token}")

# Test mode: agent sends a test HTTP request via Burp's forward proxy and then exits.
def run_agent_test():
    test_url = "http://example.com/"
    try:
        logger.info("Running agent test: connecting to Burp forward proxy...")
        sock = socket.create_connection(("127.0.0.1", 8080), timeout=20)
        sock.settimeout(20)
        request = (
            f"GET {test_url} HTTP/1.1\r\n"
            f"Host: example.com\r\n"
            f"\r\n"
        )
        sock.sendall(request.encode())
        logger.info(f"Agent test request sent:\n{request}")
        response = sock.recv(4096)
        if response:
            resp_text = response.decode(errors="replace")
            first_line = resp_text.splitlines()[0] if resp_text.splitlines() else "No status line"
            logger.info(f"Agent test successful. Response first line: {first_line}")
            logger.info(f"Full agent test response (up to 4096 bytes):\n{resp_text}")
        else:
            logger.error("Agent test received no response from Burp.")
        sock.close()
    except Exception as e:
        logger.error(f"Agent test failed: {e}")

def handle_command(command_line, control_sock, petname, use_burp=False):
    parts = command_line.split()
    if len(parts) < 3 or parts[0] != "OPEN":
        control_sock.sendall(b"ERROR Invalid command\n")
        logger.error("Invalid command received")
        return

    method = parts[1].upper()  # "CONNECT" or "HTTP"
    target = parts[2]          # e.g. "example.com:80" or "example.com:443"
    logger.info(f"Handling command: {command_line}")
    try:
        host, port_str = target.split(":")
        port = int(port_str)
    except Exception as e:
        control_sock.sendall(b"ERROR Invalid target\n")
        logger.error(f"Invalid target format '{target}': {e}")
        return

    target_sock = None
    tunnel_sock = None
    errors = []

    def open_target():
        nonlocal target_sock
        try:
            if use_burp:
                if method == "CONNECT":
                    target_sock = connect_via_burp(host, port)
                else:
                    target_sock = socket.create_connection(("127.0.0.1", 8080), timeout=5)
                    logger.info(f"Connected to Burp forward proxy for HTTP: {target}")
            else:
                target_sock = socket.create_connection((host, port), timeout=5)
                logger.info(f"Directly connected to target: {target}")
            target_sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except Exception as e:
            errors.append(f"target: {e}")
            logger.error(f"Failed to open target connection: {e}")

    def open_tunnel_conn():
        nonlocal tunnel_sock
        try:
            tunnel_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            tunnel_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server_addr = control_sock.getpeername()[0]
            tunnel_sock.connect((server_addr, TUNNEL_SERVER_PORT))
            tunnel_sock.sendall(f"TUNNEL {petname}\n".encode("utf-8"))
            logger.info(f"Tunnel connection established to server for {petname}")
        except Exception as e:
            errors.append(f"tunnel: {e}")
            logger.error(f"Failed to establish tunnel connection: {e}")

    t1 = threading.Thread(target=open_target)
    t2 = threading.Thread(target=open_tunnel_conn)
    t1.start()
    t2.start()
    t1.join()
    t2.join()

    if errors:
        err_msg = "ERROR " + "; ".join(errors) + "\n"
        control_sock.sendall(err_msg.encode("utf-8"))
        if target_sock:
            target_sock.close()
        if tunnel_sock:
            tunnel_sock.close()
        logger.error(f"Failed to open tunnel for {target}: {err_msg.strip()}")
        return

    # Signal that the tunnel is ready.
    control_sock.sendall(b"OK\n")

    # Relay logic: for HTTP with Burp, read the initial request from the tunnel, modify if needed.
    if method == "HTTP" and use_burp:
        try:
            initial_data = read_until(tunnel_sock, b"\r\n\r\n")
            if not initial_data:
                logger.error("No data received from tunnel")
                tunnel_sock.close()
                target_sock.close()
                return
            try:
                request_text = initial_data.decode("utf-8", errors="replace")
                lines = request_text.split("\r\n")
                if len(lines) < 1:
                    raise Exception("Malformed HTTP request")
                req_parts = lines[0].split(" ")
                if len(req_parts) >= 3:
                    req_method, req_path, req_version = req_parts[:3]
                    if not req_path.startswith("http://") and not req_path.startswith("https://"):
                        scheme = "https" if port == 443 else "http"
                        req_path = f"{scheme}://{host}{req_path}"
                        new_request_line = f"{req_method} {req_path} {req_version}"
                        lines[0] = new_request_line
                        modified_request = "\r\n".join(lines).encode("utf-8")
                        logger.info(f"Modified HTTP request for Burp: {new_request_line}")
                    else:
                        modified_request = initial_data
                else:
                    modified_request = initial_data
                target_sock.sendall(modified_request)
            except Exception as e:
                logger.error(f"Error processing HTTP request for Burp: {e}")
                target_sock.sendall(initial_data)
        except Exception as ex:
            logger.error(f"Failed to read initial data: {ex}")

    # Set up bidirectional relay.
    t_relay1 = threading.Thread(target=relay, args=(tunnel_sock, target_sock), daemon=True)
    t_relay2 = threading.Thread(target=relay, args=(target_sock, tunnel_sock), daemon=True)
    t_relay1.start()
    t_relay2.start()
    t_relay1.join()
    t_relay2.join()

    # Now shutdown and close both sockets.
    try:
        tunnel_sock.shutdown(socket.SHUT_RDWR)
    except Exception as e:
        logger.error(f"Error shutting down tunnel socket: {e}")
    try:
        target_sock.shutdown(socket.SHUT_RDWR)
    except Exception as e:
        logger.error(f"Error shutting down target socket: {e}")
    tunnel_sock.close()
    target_sock.close()

    logger.info(f"Tunnel closed for {target}")

def control_loop(control_sock, petname, use_burp=False):
    while True:
        cmd_line = recv_line(control_sock)
        if not cmd_line:
            logger.info("Control connection closed.")
            break
        logger.info(f"Received command: {cmd_line}")
        threading.Thread(target=handle_command,
                         args=(cmd_line, control_sock, petname, use_burp),
                         daemon=True).start()
    control_sock.close()

def main():
    parser = argparse.ArgumentParser(description="Reverse Proxy Agent")
    parser.add_argument("--server", default="proxy.fuzz-e.io",
                        help="Server IP or hostname for control connection (default: proxy.fuzz-e.io)")
    parser.add_argument("--email", required=True, help="User email address")
    parser.add_argument("--petname", help="Optional agent petname; if not provided, one is generated")
    parser.add_argument("--token", help="Optional agent token; if not provided, a random one is generated")
    parser.add_argument("--burp_suite", action="store_true",
                        help="Enable proxying through Burp Suite (traffic is forwarded via 127.0.0.1:8080)")
    parser.add_argument("--test", action="store_true", help="Run test mode to verify Burp connection and exit")
    args = parser.parse_args()

    petname_value = args.petname if args.petname else petname_lib.generate(3, '-')
    token = args.token if args.token else generate_random_string(16)
    logger.info(f"Using petname: {petname_value}, token: {token}")

    try:
        control_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        control_sock.connect((args.server, CONTROL_SERVER_PORT))
        logger.info(f"Connected to control at {args.server}:{CONTROL_SERVER_PORT}")
    except Exception as e:
        logger.error(f"Failed to connect to control server at {args.server}:{CONTROL_SERVER_PORT}. Error: {e}")
        return

    if args.burp_suite:
        if not hasattr(args, 'cert_path') or args.cert_path is None:
            args.cert_path = 'burp_cert.crt'
        if not os.path.exists(args.cert_path):
            logger.info(f"Certificate not found at {args.cert_path}. Attempting to download it...")
            try:
                args.cert_path = download_burp_cert('http://burp/cert', args.cert_path,
                                                    {"http": "http://127.0.0.1:8080", "https": "http://127.0.0.1:8080"})
            except Exception as e:
                logger.error(f"Failed to obtain Burp certificate: {e}")
        else:
            args.cert_path = convert_cert_to_pem(args.cert_path)
    else:
        args.cert_path = None

    register_agent(control_sock, args.email, petname_value, token)
    
    if args.test and args.burp_suite:
        run_agent_test()
        logger.info("Agent test complete. Exiting test mode.")
        return

    control_loop(control_sock, petname_value, use_burp=args.burp_suite)

if __name__ == "__main__":
    main()
