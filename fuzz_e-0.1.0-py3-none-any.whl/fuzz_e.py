import socketio
import requests
import os
import petname
import argparse
import certifi
import subprocess
from urllib.parse import urlparse, urlunparse
import json
import os
from OpenSSL import crypto


def is_running_in_docker():
    return os.path.exists('/.dockerenv')
    
# Removed the initial definition of FUZZ_E_DYNAMIC_ENDPOINT
if is_running_in_docker():
    HOST_IP = 'host.docker.internal'
else:
    HOST_IP = 'localhost'

sio = socketio.Client()
this_agent_petname = petname.Generate(2, '-')

def download_burp_cert(cert_url, cert_path, proxies):
    try:
        print(f"Downloading Burp certificate from {cert_url} through the proxy...")
        response = requests.get(cert_url, proxies=proxies, verify=certifi.where())
        response.raise_for_status()
        with open(cert_path, 'wb') as cert_file:
            cert_file.write(response.content)
        print(f"Certificate downloaded and saved to {cert_path}")
        convert_cert_to_pem(cert_path)
    except Exception as e:
        print(f"Failed to download Burp certificate: {e}")
        raise

def convert_cert_to_pem(cert_path):
    pem_path = cert_path.replace('.crt', '.pem')
   
    print("OpenSSL not found. Falling back to pyOpenSSL for conversion.")
    try:
        with open(cert_path, 'rb') as cert_file:
            cert_data = cert_file.read()
        x509 = crypto.load_certificate(crypto.FILETYPE_ASN1, cert_data)
        with open(pem_path, 'wb') as pem_file:
            pem_file.write(crypto.dump_certificate(crypto.FILETYPE_PEM, x509))
        print(f"Certificate converted using pyOpenSSL and saved to {pem_path}")
    except Exception as e:
        print(f"Failed to convert certificate: {e}")
        raise
    return pem_path

def send_test_request(proxies, cert_path):
    if cert_path:
        pem_path = cert_path.replace('.crt', '.pem')
        verify = pem_path
    else:
        verify = certifi.where()  # Use default SSL verification

    try:
        print("Sending test request to https://autonomouscyberco.com...")
        response = requests.get("https://autonomouscyberco.com", proxies=proxies, verify=verify)
        print(f"Test request status code: {response.status_code}")
        print(f"Test request response: {response.text[:200]}...")  # Print the first 200 characters of the response
    except requests.exceptions.SSLError as ssl_error:
        print(f"SSL Error during test request: {ssl_error}")
        print("Retrying with certifi CA bundle...")
        try:
            response = requests.get("https://autonomouscyberco.com", proxies=proxies, verify=certifi.where())
            print(f"Test request status code with certifi: {response.status_code}")
            print(f"Test request response with certifi: {response.text[:200]}...")
        except Exception as fallback_error:
            print(f"Error during test request with certifi: {fallback_error}")
    except Exception as e:
        print(f"Error during test request: {e}")

@sio.event
def connect():
    print("Connected to the main app")
    print(f'Socket ID: {sio.sid}')
    print(f'Agent ID: {this_agent_petname}')

@sio.event
def disconnect():
    print("Disconnected from the main app")

# Handle incoming requests from the main app

def parse_headers(headers_str):
    headers = {}
    for line in headers_str.splitlines():
        if ': ' in line:
            key, value = line.split(': ', 1)
            headers[key.strip()] = value.strip()
    return headers
    
@sio.on('attack_request')
def on_request(data):
    print("Received request from main app:", data)
    generated_request_dictionary = data['attack_request']
    user_headers_dict = data.get('user_headers_dict', {})

    request_details = generated_request_dictionary
    method = request_details.get("method")
    url = request_details.get("url")
    headers = request_details.get("headers", {})
    body = request_details.get("body", "")

    # Extract 'verify' parameter, defaulting to True if not provided
    verify = request_details.get('verify', True)

    # Merge user headers
    if isinstance(user_headers_dict, str):
        parsed_headers = parse_headers(user_headers_dict)
        headers.update(parsed_headers)
    elif isinstance(user_headers_dict, dict):
        headers.update(user_headers_dict)
        
    # Parse the URL
    parsed_url = urlparse(url)
    original_hostname = parsed_url.hostname

    # Detect if the URL is pointing to a local address
    local_addresses = ['localhost', '127.0.0.1', '::1']

    if parsed_url.hostname in local_addresses:
        # Ensure Host header is set to original hostname
        headers.setdefault('Host', original_hostname)
        if args.burp_proxy is None:
            # Not using Burp proxy, replace hostname with HOST_IP
            print(f"Not using burp_proxy and URL is local ({parsed_url.hostname}), replacing with HOST_IP ({HOST_IP})")
            netloc = parsed_url.netloc.replace(parsed_url.hostname, HOST_IP)
            parsed_url = parsed_url._replace(netloc=netloc)
            url = urlunparse(parsed_url)
        else:
            # Using Burp proxy, do not modify the URL
            print(f"Using burp_proxy, not modifying local URL ({parsed_url.hostname})")
    else:
        # If Host header is not set, use the hostname from the URL
        headers.setdefault('Host', parsed_url.hostname)

    # Create a session
    session = requests.Session()

    # Prepare the request
    req = requests.Request(method=method, url=url, headers=headers)

    # Set the body directly, handling any type
    if isinstance(body, (str, bytes)):
        req.data = body
    else:
        # Convert other types to string
        req.data = str(body)

    # Prepare the request
    prepared = req.prepare()

    # Determine proxies and SSL verification to use
    if args.burp_proxy is not None:
        proxies = {
            "http": args.burp_proxy or f"http://{HOST_IP}:8080",
            "https": args.burp_proxy or f"http://{HOST_IP}:8080"
        }

        # Use provided cert_path or default to 'burp_cert.pem'
        verify = args.cert_path if args.cert_path else 'burp_cert.pem'

        # Ensure the certificate file exists
        if not os.path.exists(verify):
            print(f"Certificate not found at {verify}. Attempting to download it...")
            try:
                download_burp_cert('http://burp/cert', 'burp_cert.crt', proxies)
                verify = convert_cert_to_pem('burp_cert.crt')
            except Exception as e:
                print(f"Failed to obtain Burp certificate: {e}")
                # Optionally, you can set verify to False or handle the error as needed
    else:
        proxies = None
        verify = certifi.where()  # Use default SSL verification

    # Override 'verify' if provided in 'attack_request'
    if isinstance(verify, str) and not os.path.isfile(verify):
        # If verify is a string but the file does not exist, default to certifi
        print(f"Verify path {verify} does not exist. Falling back to default CA bundle.")
        verify = certifi.where()

    try:
        # Send the request with the correct 'verify' parameter
        response = session.send(prepared, proxies=proxies, verify=verify)
        print(f"Response Status Code: {response.status_code}")

        # Send the response back to the main app
        response_data = {
            'status_code': response.status_code,
            'headers': dict(response.headers),
            'body': response.text
        }
        sio.emit('agent_response', [str(response_data['status_code']),
                                     json.dumps(response_data['headers']),
                                     response_data['body']])
    except requests.exceptions.SSLError as ssl_error:
        print(f"SSL Error: {ssl_error}")
        sio.emit('agent_response', [f'SSL Error: {ssl_error}', '', ''])
    except requests.exceptions.ProxyError as proxy_error:
        print(f"Proxy Error: {proxy_error}")
        sio.emit('agent_response', [f'Proxy Error: {proxy_error}', '', ''])
    except Exception as e:
        print(f"Error: {e}")
        sio.emit('agent_response', [str(e), '', ''])

def main():
    global args, FUZZ_E_DYNAMIC_ENDPOINT  # Declare as global to use in event handlers if necessary

    # Parse arguments
    parser = argparse.ArgumentParser(description='Process some arguments.')
    parser.add_argument('--email', type=str, required=True, help='Email address of the user')
    parser.add_argument('--key', type=str, required=False, help='User agent key')
    parser.add_argument('--burp_proxy', nargs='?', const=f'http://{HOST_IP}:8080',
                        help=f'Burp proxy URL (default: http://{HOST_IP}:8080 if specified without a value)')
    parser.add_argument('--cert_path', type=str, required=False, default=None,
                        help='Path to the Burp CA certificate')
    parser.add_argument('--test', action='store_true',
                        help='Send a test request to https://autonomouscyberco.com')
    parser.add_argument('--env', type=str, help='Override FUZZ_E_DYNAMIC_ENDPOINT')  # Added --env argument
    args = parser.parse_args()

    # Set FUZZ_E_DYNAMIC_ENDPOINT based on the -env argument or environment variable
    if args.env:
        FUZZ_E_DYNAMIC_ENDPOINT = args.env
        print(f"FUZZ_E_DYNAMIC_ENDPOINT overridden by -env argument: {FUZZ_E_DYNAMIC_ENDPOINT}")
    else:
        FUZZ_E_DYNAMIC_ENDPOINT = os.getenv('FUZZ_E_DYNAMIC_ENDPOINT', 'https://dynamic.fuzz-e.io')
        print(f"FUZZ_E_DYNAMIC_ENDPOINT set to: {FUZZ_E_DYNAMIC_ENDPOINT}")

    # Determine proxies and SSL verification based on arguments
    if args.burp_proxy is not None:
        proxies = {
            "http": args.burp_proxy or f"http://{HOST_IP}:8080",
            "https": args.burp_proxy or f"http://{HOST_IP}:8080"
        }

        # Set default cert_path if not provided
        if args.cert_path is None:
            args.cert_path = 'burp_cert.crt'

        # Check if the cert file exists, if not download it
        if not os.path.exists(args.cert_path):
            print(f"Certificate not found at {args.cert_path}. Attempting to download it...")
            try:
                download_burp_cert('http://burp/cert', args.cert_path, proxies)
                args.cert_path = convert_cert_to_pem(args.cert_path)
            except Exception as e:
                print(f"Failed to obtain Burp certificate: {e}")
                # Optionally, handle the error as needed
        else:
            # Convert the cert if it already exists
            args.cert_path = convert_cert_to_pem(args.cert_path)
    else:
        proxies = None
        args.cert_path = None  # No cert path when not using Burp proxy

    # Send a test request if the --test flag is set
    if args.test:
        send_test_request(proxies, args.cert_path)
    else:
        try:
            # Connect to the main app WebSocket server
            sio.connect(FUZZ_E_DYNAMIC_ENDPOINT)

            # Register agent with the main app
            sio.emit('register_agent', {'email': args.email, 'petname': this_agent_petname})

            # Keep the connection alive
            sio.wait()
        except KeyboardInterrupt:
            print("\nDetected CTRL + C. Shutting down gracefully...")
            sio.disconnect()
            print("Disconnected from the main app. Exiting.")
        except Exception as e:
            print(f"Failed to connect to {FUZZ_E_DYNAMIC_ENDPOINT}: {e}")
            exit(1)

if __name__ == "__main__":
    main()
