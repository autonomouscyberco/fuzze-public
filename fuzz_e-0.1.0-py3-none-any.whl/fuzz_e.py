#!/usr/bin/env python3
"""
Reverse Proxy Agent with Registration and Token-Based Authentication

Usage:
    python agent.py --server <SERVER_IP_OR_HOST> --email user@example.com [--petname happy-daisy] [--token s3cr3t]

Workflow:
  1. On startup, the agent uses provided (or generated) petname and token.
  2. It connects to the server’s control port (5000) and sends a JSON registration message.
  3. Then it enters a control loop, where for each command received (e.g., "OPEN CONNECT www.google.com:443")
     it spawns a new thread that concurrently opens a TCP connection to the target and a tunnel connection to the server’s tunnel port (6000).
  4. Immediately upon establishing the tunnel, the agent sends "TUNNEL <petname>\n" so the server can match it.
  5. The agent sends back "OK\n" on the control channel and then relays raw bytes between the target and the tunnel.
"""

import socket
import threading
import argparse
import json
import random, string

# Import petname library with an alias to avoid conflicts with variable names.
import petname as petname_lib

CONTROL_SERVER_PORT = 5000
TUNNEL_SERVER_PORT = 6000

def recv_line(sock):
    line = b""
    while not line.endswith(b"\n"):
        part = sock.recv(1)
        if not part:
            break
        line += part
    return line.decode("utf-8").strip()

def generate_random_string(n):
    return "".join(random.choice(string.ascii_lowercase + string.digits) for _ in range(n))

def register_agent(control_sock, email, petname, token):
    reg_msg = {
        "action": "register",
        "email": email,
        "petname": petname,
        "token": token
    }
    msg = json.dumps(reg_msg) + "\n"
    control_sock.sendall(msg.encode("utf-8"))
    print(f"[Agent] Registered with petname: {petname}, token: {token}")

def handle_command(command_line, control_sock, petname):
    parts = command_line.split()
    if len(parts) < 3 or parts[0] != "OPEN":
        control_sock.sendall(b"ERROR Invalid command\n")
        return
    method = parts[1]
    target = parts[2]
    print(f"[Agent] Handling command: {command_line}")
    print(f"[Agent] Target URL: {target}")
    try:
        host, port_str = target.split(":")
        port = int(port_str)
    except Exception as e:
        control_sock.sendall(b"ERROR Invalid target\n")
        return

    target_sock = None
    tunnel_sock = None
    errors = []

    def open_target():
        nonlocal target_sock
        try:
            target_sock = socket.create_connection((host, port), timeout=5)
            target_sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            print(f"[Agent] Opened connection to target {target}")
        except Exception as e:
            errors.append(f"target: {e}")

    def open_tunnel_conn():
        nonlocal tunnel_sock
        try:
            tunnel_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            tunnel_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            tunnel_sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            server_addr = control_sock.getpeername()[0]
            tunnel_sock.connect((server_addr, TUNNEL_SERVER_PORT))
            tunnel_sock.sendall(f"TUNNEL {petname}\n".encode("utf-8"))
            print(f"[Agent] Tunnel connection established to server for {petname}")
        except Exception as e:
            errors.append(f"tunnel: {e}")

    t1 = threading.Thread(target=open_target)
    t2 = threading.Thread(target=open_tunnel_conn)
    t1.start()
    t2.start()
    t1.join()
    t2.join()

    if errors:
        err_msg = "ERROR " + "; ".join(errors) + "\n"
        control_sock.sendall(err_msg.encode("utf-8"))
        if target_sock:
            target_sock.close()
        if tunnel_sock:
            tunnel_sock.close()
        print(f"[Agent] Failed to open tunnel for {target}: {err_msg.strip()}")
        return

    control_sock.sendall(b"OK\n")
    print(f"[Agent] Tunnel established for {target}")

    def relay(src, dst):
        try:
            while True:
                data = src.recv(4096)
                if not data:
                    break
                dst.sendall(data)
        except Exception:
            pass
        finally:
            try:
                src.close()
            except:
                pass
            try:
                dst.close()
            except:
                pass

    t3 = threading.Thread(target=relay, args=(tunnel_sock, target_sock), daemon=True)
    t4 = threading.Thread(target=relay, args=(target_sock, tunnel_sock), daemon=True)
    t3.start()
    t4.start()
    t3.join()
    t4.join()
    print(f"[Agent] Tunnel closed for {target}")

def control_loop(control_sock, petname):
    while True:
        cmd_line = recv_line(control_sock)
        if not cmd_line:
            print("[Agent] Control connection closed.")
            break
        print(f"[Agent] Received command: {cmd_line}")
        threading.Thread(target=handle_command, args=(cmd_line, control_sock, petname), daemon=True).start()
    control_sock.close()

def main():
    parser = argparse.ArgumentParser(description="Reverse Proxy Agent")
    parser.add_argument("--server", default="proxy.fuzz-e.io", help="Server IP or hostname for control connection (default: proxy.fuzz-e.io)")
    parser.add_argument("--email", required=True, help="User email address")
    parser.add_argument("--petname", help="Optional agent petname; if not provided, one is generated")
    parser.add_argument("--token", help="Optional agent token; if not provided, a random one is generated")
    args = parser.parse_args()

    # Generate a three-word petname if not provided.
    petname_value = args.petname if args.petname else petname_lib.generate(3, '-')
    token = args.token if args.token else generate_random_string(16)

    print(f"[Agent] Using petname: {petname_value}, token: {token}")

    control_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    control_sock.connect((args.server, CONTROL_SERVER_PORT))
    print(f"[Agent] Connected to control at {args.server}:{CONTROL_SERVER_PORT}")
    register_agent(control_sock, args.email, petname_value, token)
    control_loop(control_sock, petname_value)

if __name__ == "__main__":
    main()
